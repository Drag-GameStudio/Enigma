def get_text_from_array(arr: list):
        exit_str: str = ""
        for char in arr:
            exit_str += char

        return exit_str
